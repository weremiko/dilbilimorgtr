interface TranscriptionOptions {
  broad: boolean
}

const vowelMap: Record<string, string> = {
  a: "a", // Will be determined by context (predorsal/postdorsal)
  e: "e", // Will be determined by context ([ε] open / [e] closed)
  ı: "ɪ", // DEFAULT is [ɪ], will use [ɨ] or [i:] based on context
  i: "i", // Front unrounded high
  o: "ɔ", // Default to open [ɔ] for all root 'o' sounds
  ö: "ø", // Front rounded mid
  u: "u", // Back rounded high
  ü: "y", // Front rounded high
  â: "aː", // Long fronted a
  î: "iː", // Long i
  û: "uː", // Long u
}

const consonantMap: Record<string, string> = {
  b: "b",
  c: "d͡ʒ",
  ç: "t͡ʃ",
  d: "d",
  f: "f",
  g: "ɡ",
  h: "h",
  j: "ʒ",
  k: "k", // Will be modified based on context
  l: "l", // Will be modified based on context
  m: "m",
  n: "n",
  p: "p",
  r: "ɾ", // Will become [ɣ] at word-final position
  s: "s",
  ş: "ʃ",
  t: "t",
  v: "v",
  y: "j",
  z: "z",
}

// Common loanwords with epenthesis (içses türemesi)
const epenthesisWords: Record<string, string> = {
  tren: "tiren",
  fren: "firen",
  grip: "girip",
  spor: "sipor",
  kral: "kıral",
  plan: "pilan",
  plaj: "pilaj",
  gram: "giram",
  stat: "istat",
  stres: "sitres",
}

function isFrontVowel(char: string): boolean {
  return "eiöüEİÖÜ".includes(char)
}

function isBackVowel(char: string): boolean {
  return "aıouAIOU".includes(char)
}

function isVowel(char: string): boolean {
  return "aeıioöuüâîûAEIİOÖUÜÂÎÛ".includes(char)
}

function isConsonant(char: string): boolean {
  return "bcçdfgğhjklmnprsştvyzBCÇDFGĞHJKLMNPRSŞTVYZ".includes(char)
}

function applyFinalDevoicing(char: string): string {
  const devoicingMap: Record<string, string> = {
    b: "p",
    c: "t͡ʃ",
    d: "t",
    g: "k",
    ğ: "k",
  }
  return devoicingMap[char] || char
}

// Check if word needs epenthesis (vowel insertion for consonant clusters)
function applyEpenthesis(word: string): string {
  const lowerWord = word.toLowerCase()
  if (epenthesisWords[lowerWord]) {
    return epenthesisWords[lowerWord]
  }
  return word
}

// Apply assimilation rules (benzeşme)
function applyAssimilation(chars: string[], index: number): string | null {
  const current = chars[index]
  const next = index < chars.length - 1 ? chars[index + 1] : ""
  
  // nb > mb (dudak ünsüzü benzeşmesi)
  if (current === "n" && next === "b") {
    return "m"
  }
  
  // nl > nn (yan ses benzeşmesi)
  if (current === "n" && next === "l") {
    return "n"
  }
  
  // zs > ss (ötümsüzleşme benzeşmesi)
  if (current === "z" && next === "s") {
    return "s"
  }
  
  // cz > zz (ötümlüleşme benzeşmesi)
  if (current === "c" && next === "z") {
    return "z"
  }
  
  return null
}

// Find all vowels in the word and determine syllable positions
function findVowelPositions(chars: string[]): number[] {
  const positions: number[] = []
  for (let i = 0; i < chars.length; i++) {
    if (isVowel(chars[i])) {
      positions.push(i)
    }
  }
  return positions
}

// Determine stress position (simplified)
function getStressPosition(word: string): number {
  const lowerWord = word.toLowerCase()
  const chars = lowerWord.split("")
  const vowelPositions = findVowelPositions(chars)
  
  if (vowelPositions.length === 0) return -1
  
  // Negative suffix -ma/-me gets stress
  if (lowerWord.endsWith("ma") || lowerWord.endsWith("me")) {
    return vowelPositions[vowelPositions.length - 1]
  }
  
  // Place names often have stress on last syllable (capitalized words)
  if (word[0] === word[0].toUpperCase() && word.length > 1) {
    return vowelPositions[vowelPositions.length - 1]
  }
  
  // Default: penultimate syllable (second to last)
  if (vowelPositions.length >= 2) {
    return vowelPositions[vowelPositions.length - 2]
  }
  
  // Single vowel word: that vowel is stressed
  return vowelPositions[0]
}

function transcribeWord(word: string, options: TranscriptionOptions, isSentenceFinal = false): string {
  let result = ""
  
  // Apply epenthesis first
  let processedWord = applyEpenthesis(word.toLowerCase())
  const chars = processedWord.split("")
  const originalWord = word.toLowerCase()
  const stressPosition = getStressPosition(originalWord)

  for (let i = 0; i < chars.length; i++) {
    const char = chars[i]
    const prev = i > 0 ? chars[i - 1] : ""
    const next = i < chars.length - 1 ? chars[i + 1] : ""
    const isLastChar = i === chars.length - 1
    const isStressed = i === stressPosition

    // Skip punctuation
    if (char.match(/[\s.,!?;:\-()'"]/)) {
      continue
    }

    // Add stress marker before stressed vowel (in narrow transcription)
    if (!options.broad && isStressed && isVowel(char)) {
      result += "'"
    }

    // Handle yumuşak g (ğ) - vowel lengthening
    if (char === "ğ") {
      if (result.length > 0 && isVowel(prev)) {
        result += "ː"
      }
      continue
    }

    // Check for assimilation
    const assimilated = applyAssimilation(chars, i)
    if (assimilated) {
      result += assimilated
      continue
    }

    // Handle vowels
    if (vowelMap[char]) {
      let vowel = vowelMap[char]
      
      // Handle 'a' - predorsal (ince) vs postdorsal (kalın)
      if (char === "a") {
        const hasFrontContext = isFrontVowel(next) || isFrontVowel(prev)
        if (hasFrontContext && !options.broad) {
          vowel = "a" // predorsal (ince a)
        } else {
          vowel = "ɑ" // postdorsal (kalın a)
        }
      }
      
      // Handle 'e' - [ε] (open) vs [e] (closed)
      // Rule: Use [ε] in stressed syllables and word-final positions
      if (char === "e") {
        if (!options.broad) {
          if (isStressed || isLastChar) {
            vowel = "ε" // open e (like "ev", "el", "sen")
          } else {
            vowel = "e" // closed e
          }
        } else {
          vowel = "e"
        }
      }
      
      // Handle 'o' - [ɔ] (open) is the DEFAULT for all root 'o' sounds
      // Rule: Kelime kökündeki sade "o" sesleri için [ɔ] kullan
      if (char === "o") {
        if (!options.broad) {
          vowel = "ɔ" // default to open o (like "soru" [sɔ'ru])
        } else {
          vowel = "o"
        }
      }
      
      // Handle 'ı' - [ɪ] is the DEFAULT
      // Rules from attachment:
      // - [i:]: Long sounds (uzun seslerde) - ONLY when followed by ğ e.g., iğde [i:'dε]
      // - [ɪ]: DEFAULT - narrow, straight, closed position - e.g., simit [sɪ'mɪt]
      // - [ɨ]: Arkadil/Ortadil I ONLY when word-initial or after back vowels - e.g., ısı [ɨ'sɪ]
      if (char === "ı") {
        if (!options.broad) {
          // Check if it's a long vowel (ONLY when followed by ğ)
          const isLong = next === "ğ"
          
          // Check if word-initial position
          const isWordInitial = i === 0
          
          // Check if after a back vowel (a, ı, o, u)
          const afterBackVowel = prev && "aıou".includes(prev.toLowerCase())
          
          if (isLong) {
            vowel = "i" // Will be lengthened with ː later
          } else if (isWordInitial || afterBackVowel) {
            vowel = "ɨ" // Arkadil/Ortadil I (like "ısı" [ɨ'sɪ])
          } else {
            vowel = "ɪ" // DEFAULT Kapalı İ/I (like "simit" [sɪ'mɪt])
          }
        } else {
          vowel = "ɪ" // In broad transcription, use [ɪ] instead of [ɯ]
        }
      }
      
      // Vowel narrowing with /y/ influence (daralma)
      if ((char === "e" || char === "a") && next === "y") {
        const afterY = i < chars.length - 2 ? chars[i + 2] : ""
        if (isVowel(afterY)) {
          if (!options.broad) {
            vowel = char === "e" ? "i" : "ɨ"
            vowel += "ː"
          }
        }
      }
      
      result += vowel
      continue
    }

    // Dark L vs Light L
    if (char === "l") {
      const prevIsFront = prev && isFrontVowel(prev)
      const nextIsFront = next && isFrontVowel(next)
      const prevIsBack = prev && isBackVowel(prev)
      const nextIsBack = next && isBackVowel(next)

      if (prevIsFront || nextIsFront) {
        result += "l" // Light l
      } else if (prevIsBack || nextIsBack || isLastChar) {
        result += "ɫ" // Dark/velarized l
      } else {
        result += "l"
      }
      continue
    }

    // Palatal k vs velar k
    if (char === "k") {
      const prevIsFront = prev && isFrontVowel(prev)
      const nextIsFront = next && isFrontVowel(next)

      if (prevIsFront || nextIsFront) {
        result += "c" // Palatal k
      } else {
        result += "k" // Velar k
      }
      continue
    }

    // Palatal g vs velar g
    if (char === "g") {
      const prevIsFront = prev && isFrontVowel(prev)
      const nextIsFront = next && isFrontVowel(next)

      if (prevIsFront || nextIsFront) {
        result += "ɟ" // Palatal g
      } else {
        result += "ɡ" // Velar g
      }
      continue
    }

    // Handle 'r' - [ɣ] (Sürtünücü R) at sentence-final position
    // Rule: Cümlenin sonunda r varsa [ɣ] koy
    if (char === "r") {
      if (!options.broad && isLastChar && isSentenceFinal) {
        result += "ɣ" // Fricative r at sentence-final (like "bir" at end of sentence)
      } else {
        result += "ɾ" // Standard tap/flap r
      }
      continue
    }

    // Final devoicing (sonseste ötümsüzleşme)
    if (isLastChar && "bcdgğ".includes(char)) {
      const devoiced = applyFinalDevoicing(char)
      result += devoiced
      continue
    }

    // Velar nasal [ŋ] before k/g
    if (char === "n" && next && "kgğKGĞ".includes(next)) {
      result += "ŋ"
      continue
    }

    // Standard consonants
    if (consonantMap[char]) {
      result += consonantMap[char]
    } else {
      result += char
    }
  }

  return result
}

export function turkishToIPA(text: string, options: TranscriptionOptions): string {
  if (!text) return ""

  // Split by whitespace and punctuation, but keep punctuation
  const tokens = text.split(/(\s+|[.,!?;:—\-()'"«»""])/g)
  
  // Find the last word token (for sentence-final r → ɣ rule)
  let lastWordIndex = -1
  for (let i = tokens.length - 1; i >= 0; i--) {
    if (tokens[i] && !tokens[i].match(/^[\s.,!?;:—\-()'"«»""]+$/)) {
      lastWordIndex = i
      break
    }
  }

  const transcribedTokens = tokens.map((token, index) => {
    // Skip empty tokens
    if (!token) return ""

    // Keep whitespace and punctuation as-is
    if (token.match(/^[\s.,!?;:—\-()'"«»""]+$/)) {
      return token
    }

    // Check if this is the last word in the sentence
    const isSentenceFinal = index === lastWordIndex
    
    // Transcribe words
    const transcribed = transcribeWord(token, options, isSentenceFinal)
    return options.broad ? `/${transcribed}/` : `[${transcribed}]`
  })

  return transcribedTokens.join("")
}
