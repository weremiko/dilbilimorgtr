import { TranscriberPage } from "@/components/transcriber-page"

export default function TranscriberRoute() {
  return <TranscriberPage />
}
